#include "minishell.h"
#include "struct.h"


int			c_enametoolong(char *path)
{
	int		i;
	char	*buf;

	i = 2;
	if (ft_strlen(path) >= 1024)
		return (0);
	while ((buf = ft_strcut(path, "/", i)))
	{
		if (ft_strlen(buf) >= 1024)
		{
			free(buf);
			return (0);
		}
		if (!*buf)
		{
			free(buf);
			break ;
		}
		free(buf);
		i++;
	}
	return (1);
}
int			c_enotdir(char *path)
{
	struct stat		buf;

	if (!lstat(path, &buf))
		if (!(S_IFDIR == (S_IFMT & buf.st_mode)))
			return (0);
	return (1);
}
